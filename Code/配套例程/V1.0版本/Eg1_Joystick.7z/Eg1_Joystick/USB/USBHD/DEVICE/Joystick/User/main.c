/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : main Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2023/10/7
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */

/*******************************************************************************/
/* Header Files */
#include "usbd_composite_km.h"
#include "ch32v10x_usbfs_device.h"
#include "adc.h"
#include "Button.h"
#include "string.h"
/*  Re-maps a number from one range to another
 *
 */
u32 map(u32 x, u32 in_min, u32 in_max, u32 out_min, u32 out_max) {
    if (x > in_max) {
        return out_max;
    } else if (x < in_min) {
        return out_min;
    } else {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

}

/*********************************************************************
 * @fn      main
 *
 * @brief   Main program
 *
 * @return  none
 */
int main(void) {
    u8 Joystick_Report[3] = { 0 };
    u8 LastJoystick_Report[3] = { 0 };
    /* Initialize system configuration */
    NVIC_PriorityGroupConfig( NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d\r\n", SystemCoreClock);

    /* Initialize USBHD interface to communicate with the host  */
    USBHD_RCC_Init();
    USBHD_Device_Init(ENABLE, PWR_VDD_SupplyVoltage());
    USB_Sleep_Wakeup_CFG();
    Adc_Init();
    buttonGPIOInit();
    printf("USBHD Joystick Device Test\r\n");

    while( 1 )
    {
        if( USBHD_DevEnumStatus )
        {
            Joystick_Report[1]=map(Get_Adc_Average(1,10),AD_XMIN,AD_XMAX,0,255);
            Joystick_Report[0]=map(Get_Adc_Average(2,10),AD_YMIN,AD_YMAX,0,255);
            Joystick_Report[2]=Button_scan();
            if(memcmp(LastJoystick_Report,Joystick_Report,
                            sizeof(Joystick_Report) / sizeof(Joystick_Report[0]))!=0)
            {
                USBHD_Endp_DataUp( DEF_UEP1, Joystick_Report,
                        sizeof(Joystick_Report) / sizeof(Joystick_Report[0]), DEF_UEP_CPY_LOAD );
            }
            memcpy(LastJoystick_Report,Joystick_Report,
                    sizeof(Joystick_Report) / sizeof(Joystick_Report[0]));

        }
    }
}
