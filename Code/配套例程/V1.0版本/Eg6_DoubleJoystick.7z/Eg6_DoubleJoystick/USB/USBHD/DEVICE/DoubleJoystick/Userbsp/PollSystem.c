/**
 ******************************************************************************
 * @file           : ws281x.c
 * @brief          : led Driver
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2021/11/30
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include "PollSystem.h"
#include "Button.h"
#include "adc.h"
#include "ws281x.h"
#include "ch32v10x_usbfs_device.h"
vu32 uwTick;

MultiTimer timer1;
MultiTimer timer2;
MultiTimer timer3;
MultiTimer timer4;

#define  X_BASE             128
#define  Y_BASE             128
#define  DIV                5






void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

uint64_t PlatformTicksGetFunc(void) {
    return uwTick;
}

/**
  * @brief This function provides minimum delay (in milliseconds) based
  *        on variable incremented.
  * @note In the default implementation , SysTick timer is the source of time base.
  *       It is used to generate interrupts at regular time intervals where uwTick
  *       is incremented.
  * @note This function is declared as __weak to be overwritten in case of other
  *       implementations in user file.
  * @param Delay specifies the delay time length, in milliseconds.
  * @retval None
  */
#define HAL_MAX_DELAY      0xFFFFFFFFU
void HAL_Delay(uint32_t Delay)
{
  uint32_t tickstart = PlatformTicksGetFunc();
  uint32_t wait = Delay;

  /* Add a freq to guarantee minimum wait */
  if (wait < HAL_MAX_DELAY)
  {
    wait += (uint32_t)(1);
  }

  while ((PlatformTicksGetFunc() - tickstart) < wait)
  {
  }
}


u8 buttonSemaphore = 0;
u8 button = 0;
void ButtonTimer1Callback(MultiTimer* timer, void *userData) {
    printf("Button_scan\r\n");
    if (buttonSemaphore == 0) {

        button=Button_scan();
        buttonSemaphore = 1;
    }

    MultiTimerStart(timer, 5, ButtonTimer1Callback, userData);
}
u8 adcSemaphore = 0;
u8 xtemp = 0, ytemp = 0;
u16 adxsum=0,adysum=0,adcount=0;
void ADCTimer2Callback(MultiTimer* timer, void *userData) {
    printf("ADC Sample\r\n");

    if (adcSemaphore == 0) {

        adysum+=Get_Adc(1);
        adxsum+=Get_Adc(2);

        if(++adcount==10)
        {
            printf("x=%d,y=%d\r\n",adysum/adcount,adxsum/adcount);
            ytemp = map(adysum/adcount, AD_XMIN, AD_XMAX, 0, 255);
            xtemp = map(adxsum/adcount, AD_YMIN, AD_YMAX, 0, 255);
            adysum=0;
            adxsum=0;
            adcount=0;
            adcSemaphore = 1;
        }


    }
    MultiTimerStart(timer, 5, ADCTimer2Callback, userData);
}
u8 Joystick_Report[4] = { 0 };
u8 LastJoystick_Report[4] = { 0 };
void JoystickTimer3Callback(MultiTimer* timer, void *userData) {
    static u8 ReportId=1;
    printf("Joystick Report\r\n");
    if( USBHD_DevEnumStatus )
    {
        if(adcSemaphore)
        {
            adcSemaphore=0;
            Joystick_Report[2]=ytemp;
            Joystick_Report[1]=xtemp;
        }
        if(buttonSemaphore)
        {
            buttonSemaphore=0;
            Joystick_Report[3]=button;
        }
        if(ReportId==3)
        {
            ReportId=1;
        }
        Joystick_Report[0]=ReportId;//Report 1;
        ReportId++;

        if(memcmp(LastJoystick_Report,Joystick_Report,
                        sizeof(Joystick_Report) / sizeof(Joystick_Report[0]))!=0)
        {
            USBHD_Endp_DataUp( DEF_UEP1, Joystick_Report,
                    sizeof(Joystick_Report) / sizeof(Joystick_Report[0]), DEF_UEP_CPY_LOAD );
        }

        memcpy(LastJoystick_Report,Joystick_Report,
                sizeof(Joystick_Report) / sizeof(Joystick_Report[0]));

    }
    MultiTimerStart(timer, 8, JoystickTimer3Callback, userData);
}

void WS2812BTimer4Callback(MultiTimer* timer, void *userData) {
    printf("WS2812B\r\n");
    ws281x_rainbow();
    MultiTimerStart(timer, 100, WS2812BTimer4Callback, userData);
}
void PollSystemInit(void) {
    MultiTimerInstall(PlatformTicksGetFunc);
    MultiTimerStart(&timer1, 5, ButtonTimer1Callback, NULL);
    MultiTimerStart(&timer2, 5, ADCTimer2Callback, NULL);
    MultiTimerStart(&timer3, 8, JoystickTimer3Callback,NULL);
    MultiTimerStart(&timer4, 100, WS2812BTimer4Callback,NULL);
}

/*********************************************************************
 * @fn      SysTick_Handler
 *
 * @brief   SysTick_Handler
 *
 * @return  none
 */
void SysTick_Handler(void) {
    SysTick->CNTL0 = 0;
    SysTick->CNTL1 = 0;
    SysTick->CNTL2 = 0;
    SysTick->CNTL3 = 0;

    SysTick->CNTH0 = 0;
    SysTick->CNTH1 = 0;
    SysTick->CNTH2 = 0;
    SysTick->CNTH3 = 0;
    uwTick++;
}
