/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : main Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2023/10/7
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */

/*******************************************************************************/
/* Header Files */
#include "usbd_composite_km.h"
#include "ch32v10x_usbfs_device.h"
#include "adc.h"
#include "Button.h"
#include "string.h"
#include "ws281x.h"
#include "PollSystem.h"



/*********************************************************************
 * @fn      SYSTICK_Init_Config
 *
 * @brief   SYSTICK_Init_Config.
 *
 * @return  none
 */
void SYSTICK_Init_Config(u_int32_t ticks) {
    SysTick->CTLR = 0x0000; //�ر�ϵͳ������

    SysTick->CNTL0 = 0;
    SysTick->CNTL1 = 0;
    SysTick->CNTL2 = 0;
    SysTick->CNTL3 = 0;

    SysTick->CNTH0 = 0;
    SysTick->CNTH1 = 0;
    SysTick->CNTH2 = 0;
    SysTick->CNTH3 = 0;

    SysTick->CMPLR0 = (u8) (ticks & 0xFF);
    SysTick->CMPLR1 = (u8) (ticks >> 8);
    SysTick->CMPLR2 = (u8) (ticks >> 16);
    SysTick->CMPLR3 = (u8) (ticks >> 24);

    SysTick->CMPHR0 = 0;
    SysTick->CMPHR1 = 0;
    SysTick->CMPHR2 = 0;
    SysTick->CMPHR3 = 0;

    NVIC_SetPriority(SysTicK_IRQn, 15);
    NVIC_EnableIRQ(SysTicK_IRQn);

    SysTick->CTLR = (1 << 0);
}
/*********************************************************************
 * @fn      main
 *
 * @brief   Main program
 *
 * @return  none
 */
int main(void) {

    /* Initialize system configuration */
    NVIC_PriorityGroupConfig( NVIC_PriorityGroup_2);
    Delay_Init();
    USART_Printf_Init(115200);
    printf("SystemClk:%d\r\n", SystemCoreClock);

    /* Initialize USBHD interface to communicate with the host  */
    USBHD_RCC_Init();
    USBHD_Device_Init(ENABLE, PWR_VDD_SupplyVoltage());
    USB_Sleep_Wakeup_CFG();
    Adc_Init();
    buttonGPIOInit();
    WS281xInit();
    printf("USBHD Joystick Device Test\r\n");
    PollSystemInit();
    SYSTICK_Init_Config(SystemCoreClock / 8000 - 1);
    while( 1 )
    {
        MultiTimerYield();
    }
}


