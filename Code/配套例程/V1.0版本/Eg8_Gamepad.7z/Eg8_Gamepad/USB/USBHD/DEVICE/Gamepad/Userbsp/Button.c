/**
  ******************************************************************************
  * @file           : Button.c
  * @brief          : Button Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 LDSCITECHE Inc.
  * 未经作者许可，不得用于其它任何用途
  * 创建日期:2023/10/7
  * 版本：V1.0
  * 版权所有，盗版必究。
  * Copyright(C) 广州联盾电子科技有限公司 LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */
#include "Button.h"
/*********************************************************************
 * @fn      buttonGPIOInit
 *
 * @brief   按键IO初始化
 *
 * @param   none
 *
 * @return  none
 */
void buttonGPIOInit(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 使能GPIOA时钟

    // 配置GPIOA的Pin 0为输入下拉模式（IPD）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置GPIOA的Pin 15为输入上拉模式（IPU）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); // 使能GPIOB时钟

    // 配置GPIOB的Pin 3, 4, 5, 6, 7, 8, 9为输入上拉模式（IPU）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6
                                | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// 检测按键状态并返回按键值
/*
u8 Button_scan(void)
{
    u8 key = 0;

    // 以下是对各个按键的检测，如果按键按下（电平为低），则设置相应位为1，否则为0
    if (UPKEY() == Bit_RESET)
    {
        key |= BIT0; // 设置key的第0位为1
    }
    else
    {
        key &= (~BIT0); // 设置key的第0位为0
    }

    if (LFKEY() == Bit_RESET)
    {
        key |= BIT1; // 设置key的第1位为1
    }
    else
    {
        key &= (~BIT1); // 设置key的第1位为0
    }

    if (RGKEY() == Bit_RESET)
    {
        key |= BIT2; // 设置key的第2位为1
    }
    else
    {
        key &= (~BIT2); // 设置key的第2位为0
    }

    if (DNKEY() == Bit_RESET)
    {
        key |= BIT3; // 设置key的第3位为1
    }
    else
    {
        key &= (~BIT3); // 设置key的第3位为0
    }

    if (TBKEY() == Bit_RESET)
    {
        key |= BIT4; // 设置key的第4位为1
    }
    else
    {
        key &= (~BIT4); // 设置key的第4位为0
    }

    if (BKKEY() == Bit_RESET)
    {
        key |= BIT5; // 设置key的第5位为1
    }
    else
    {
        key &= (~BIT5); // 设置key的第5位为0
    }

    if (MDKEY() == Bit_RESET)
    {
        key |= BIT6; // 设置key的第6位为1
    }
    else
    {
        key &= (~BIT6); // 设置key的第6位为0
    }

    if (STKEY() == Bit_RESET)
    {
        key |= BIT7; // 设置key的第7位为1
    }
    else
    {
        key &= (~BIT7); // 设置key的第7位为0
    }

    return key; // 返回合并后的按键状态值
}
*/

void buttonHandler(u8* Hat,u8* But)
{
    //Hat
    if((UPKEY()==0)&&(DNKEY()==0)&&(LFKEY()==0)&&(RGKEY()!=0)) //0001
    {
        Hat[0]|=HATSW7;
    }else if((UPKEY()==0)&&(DNKEY()==0)&&(LFKEY()!=0)&&(RGKEY()==0))//0010
    {
        Hat[0]|=HATSW3;
    }else if((UPKEY()==0)&&(DNKEY()!=0)&&(LFKEY()==0)&&(RGKEY()==0))//0100
    {
        Hat[0]|=HATSW1;
    }else if((UPKEY()==0)&&(DNKEY()!=0)&&(LFKEY()==0)&&(RGKEY()!=0))//0101
    {
        Hat[0]|=HATSW8;
    }else if((UPKEY()==0)&&(DNKEY()!=0)&&(LFKEY()!=0)&&(RGKEY()==0))//0110
    {
        Hat[0]|=HATSW2;
    }else if((UPKEY()==0)&&(DNKEY()!=0)&&(LFKEY()!=0)&&(RGKEY()!=0))//0111
    {
        Hat[0]|=HATSW1;
    }else if((UPKEY()!=0)&&(DNKEY()==0)&&(LFKEY()==0)&&(RGKEY()==0))//1000
    {
        Hat[0]|=HATSW5;
    }else if((UPKEY()!=0)&&(DNKEY()==0)&&(LFKEY()==0)&&(RGKEY()!=0))//1001
    {
        Hat[0]|=HATSW6;
    }else if((UPKEY()!=0)&&(DNKEY()==0)&&(LFKEY()!=0)&&(RGKEY()==0))//1010
    {
        Hat[0]|=HATSW4;
    }else if((UPKEY()!=0)&&(DNKEY()==0)&&(LFKEY()!=0)&&(RGKEY()!=0))//1011
    {
        Hat[0]|=HATSW5;
    }else if((UPKEY()!=0)&&(DNKEY()!=0)&&(LFKEY()==0)&&(RGKEY()!=0))//1101
    {
        Hat[0]|=HATSW7;
    }else if((UPKEY()!=0)&&(DNKEY()!=0)&&(LFKEY()!=0)&&(RGKEY()==0))//1110
    {
        Hat[0]|=HATSW3;
    }else{
        Hat[0]&=(~0x3C);
    }
    //Button
     if(STKEY()==0)
    {
        But[0]|=BIT0;
    }else{
        But[0]&=(~BIT0);
    }
    if(MDKEY()==0)
    {
        But[0]|=BIT1;
    }else{
        But[0]&=(~BIT1);
    }
    if(BKKEY()==0)
    {
        But[0]|=BIT2;
    }else{
        But[0]&=(~BIT2);
    }
    if(TBKEY()==0)
    {
        But[0]|=BIT3;
    }else{
        But[0]&=(~BIT3);
    }
}


