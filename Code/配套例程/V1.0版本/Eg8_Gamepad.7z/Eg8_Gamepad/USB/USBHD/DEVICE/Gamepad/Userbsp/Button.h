/**
  ******************************************************************************
  * @file           : Button.h
  * @brief          : Button Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2023/10/7
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */

#ifndef USERBSP_BUTTON_H_
#define USERBSP_BUTTON_H_

#include "debug.h"

#define  UPKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)//PB9
#define  DNKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)//PB8
#define  LFKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)//PB7
#define  RGKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)//PB6
#define  BKKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)//PB5
#define  MDKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)//PB4
#define  STKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)//PB3
#define  TBKEY()             GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)//PA15


#define BIT0                    ((uint32_t)0x01)
#define BIT1                    ((uint32_t)0x02)
#define BIT2                    ((uint32_t)0x04)
#define BIT3                    ((uint32_t)0x08)
#define BIT4                    ((uint32_t)0x10)
#define BIT5                    ((uint32_t)0x20)
#define BIT6                    ((uint32_t)0x40)
#define BIT7                    ((uint32_t)0x80)

#define     HATSW1        0x04
#define     HATSW2        0x08
#define     HATSW3        0x0C
#define     HATSW4        0x10
#define     HATSW5        0x14
#define     HATSW6        0x18
#define     HATSW7        0x1C
#define     HATSW8        0x20


extern void buttonGPIOInit(void);
//extern u8 Button_scan(void);
extern void buttonHandler(u8* Hat,u8* But);
#endif /* USERBSP_BUTTON_H_ */
