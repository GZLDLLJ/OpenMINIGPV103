/**
  ******************************************************************************
  * @file           : Button.h
  * @brief          : Button Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2023/10/7
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */

#ifndef USERBSP_BUTTON_H_
#define USERBSP_BUTTON_H_

#include "debug.h"

#define  UPKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)//PB9
#define  DNKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)//PB8
#define  LFKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)//PB7
#define  RGKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)//PB6
#define  BKKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)//PB5
#define  MDKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)//PB4
#define  STKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)//PB3
#define  TBKEY()             GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)//PA15
#define  SW1()               GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)//PA0

#define BIT0                    ((uint32_t)0x01)
#define BIT1                    ((uint32_t)0x02)
#define BIT2                    ((uint32_t)0x04)
#define BIT3                    ((uint32_t)0x08)
#define BIT4                    ((uint32_t)0x10)
#define BIT5                    ((uint32_t)0x20)
#define BIT6                    ((uint32_t)0x40)
#define BIT7                    ((uint32_t)0x80)

#define     HATSW1        0x04
#define     HATSW2        0x08
#define     HATSW3        0x0C
#define     HATSW4        0x10
#define     HATSW5        0x14
#define     HATSW6        0x18
#define     HATSW7        0x1C
#define     HATSW8        0x20

//BUTTON MASK DEFINES
#define R3_MASK_ON 0x80
#define R3_MASK_OFF 0x7F
#define L3_MASK_ON 0x40
#define L3_MASK_OFF 0xBF
#define BACK_MASK_ON 0x20
#define BACK_MASK_OFF 0xDF
#define START_MASK_ON 0x10
#define START_MASK_OFF 0xEF
#define DPAD_RIGHT_MASK_ON 0x08
#define DPAD_RIGHT_MASK_OFF 0xF7
#define DPAD_LEFT_MASK_ON 0x04
#define DPAD_LEFT_MASK_OFF 0xFB
#define DPAD_DOWN_MASK_ON 0x02
#define DPAD_DOWN_MASK_OFF 0xFD
#define DPAD_UP_MASK_ON 0x01
#define DPAD_UP_MASK_OFF 0xFE
#define Y_MASK_ON 0x80
#define Y_MASK_OFF 0x7F
#define X_MASK_ON 0x40
#define X_MASK_OFF 0xBF
#define B_MASK_ON 0x20
#define B_MASK_OFF 0xDF
#define A_MASK_ON 0x10
#define A_MASK_OFF 0xEF
#define LOGO_MASK_ON 0x04
#define LOGO_MASK_OFF 0xFB
#define RB_MASK_ON 0x02
#define RB_MASK_OFF 0xFD
#define LB_MASK_ON 0x01
#define LB_MASK_OFF 0xFE
#define DPAD_MASK_OFF 0xF0

//Byte location Definitions
#define BUTTON_PACKET_1 2
#define BUTTON_PACKET_2 3
#define LEFT_TRIGGER_PACKET 4
#define RIGHT_TRIGGER_PACKET 5
#define LEFT_STICK_X_PACKET_LSB 6
#define LEFT_STICK_X_PACKET_MSB 7
#define LEFT_STICK_Y_PACKET_LSB 8
#define LEFT_STICK_Y_PACKET_MSB 9
#define RIGHT_STICK_X_PACKET_LSB 10
#define RIGHT_STICK_X_PACKET_MSB 11
#define RIGHT_STICK_Y_PACKET_LSB 12
#define RIGHT_STICK_Y_PACKET_MSB 13

//Classification numbers for updating controller items
#define BUTTON_A 0x01
#define BUTTON_B 0x02
#define BUTTON_X 0x03
#define BUTTON_Y 0x04
#define BUTTON_LB 0x05
#define BUTTON_RB 0x06
#define BUTTON_L3 0x07
#define BUTTON_R3 0x08
#define BUTTON_START 0x09
#define BUTTON_BACK 0x0a
#define BUTTON_LOGO 0x0b
#define DPAD_UP 0x0c
#define DPAD_DOWN 0x0d
#define DPAD_LEFT 0x0e
#define DPAD_RIGHT 0x0f
#define TRIGGER_LEFT 0x10
#define TRIGGER_RIGHT 0x11
#define STICK_LEFT 0x12
#define STICK_RIGHT 0x13

extern void buttonGPIOInit(void);
//extern u8 Button_scan(void);
extern void buttonHandler(u8* packet1,u8* packet2);
#endif /* USERBSP_BUTTON_H_ */
