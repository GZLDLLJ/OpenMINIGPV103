/**
 ******************************************************************************
 * @file           : ws281x.c
 * @brief          : led Driver
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2021/11/30
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include "PollSystem.h"
#include "Button.h"
#include "adc.h"
#include "ws281x.h"
#include "ch32v10x_usbfs_device.h"
vu32 uwTick;

MultiTimer timer1;
MultiTimer timer2;
MultiTimer timer3;
MultiTimer timer4;


uint8_t TXData[20] = {0x00, 0x14, 0x01, 0x00, 0x00,
                      0x00, 0x00, 0x00, 0x00, 0x00,
                      0x00, 0x00, 0x00, 0x00, 0x00,
                      0x00, 0x00, 0x00, 0x00, 0x00};  //Holds USB transmit packet data


void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

uint64_t PlatformTicksGetFunc(void) {
    return uwTick;
}

u8 buttonSemaphore = 0;
u8 packet1=0,packet2=0;
void ButtonTimer1Callback(MultiTimer* timer, void *userData) {
    printf("Button_scan\r\n");
    if (buttonSemaphore == 0) {
        buttonHandler(&packet1,&packet2);
        buttonSemaphore = 1;
    }

    MultiTimerStart(timer, 5, ButtonTimer1Callback, userData);
}
u8 adcSemaphore = 0;
int16_t xtemp = 0, ytemp = 0,Rxtemp=0,Rytemp=0;
u16 adxsum=0,adysum=0,adRxsum=0,adRysum=0;
u8 adcount=0;
void ADCTimer2Callback(MultiTimer* timer, void *userData) {
    printf("ADC Sample\r\n");

    if (adcSemaphore == 0) {

        adysum+=Get_Adc(1);
        adxsum+=Get_Adc(2);
        adRxsum+=Get_Adc(4);
        adRysum+=Get_Adc(5);

        if(++adcount==10)
        {
            printf("x=%d,y=%d\r\n",adysum/adcount,adxsum/adcount);

            xtemp=(int16_t)map( adxsum/adcount, AD_XMIN, AD_XMAX, INT16_MIN, INT16_MAX );
            ytemp=(int16_t)map( adysum/adcount, AD_YMIN, AD_YMAX, INT16_MAX, INT16_MIN );
            Rxtemp=(int16_t)map( adRxsum/adcount, AD_YMIN, AD_YMAX, INT16_MAX, INT16_MIN );
            Rytemp=(int16_t)map( adRysum/adcount, AD_YMIN, AD_YMAX, INT16_MAX, INT16_MIN );
            adysum=0;
            adxsum=0;
            adRxsum=0;
            adRysum=0;
            adcount=0;
            adcSemaphore = 1;
        }


    }
    MultiTimerStart(timer, 5, ADCTimer2Callback, userData);
}


void JoystickTimer3Callback(MultiTimer* timer, void *userData) {

    printf("Mouse Report\r\n");
    if( USBHD_DevEnumStatus )
    {

        if(adcSemaphore)
        {
            adcSemaphore=0;

            TXData[LEFT_STICK_X_PACKET_LSB] = LOBYTE(xtemp);        // (CONFERIR)
            TXData[LEFT_STICK_X_PACKET_MSB] = HIBYTE(xtemp);

            TXData[LEFT_STICK_Y_PACKET_LSB] = LOBYTE(ytemp);
            TXData[LEFT_STICK_Y_PACKET_MSB] = HIBYTE(ytemp);

            TXData[RIGHT_STICK_X_PACKET_LSB] = LOBYTE(Rxtemp);      // (CONFERIR)
            TXData[RIGHT_STICK_X_PACKET_MSB] = HIBYTE(Rxtemp);

            TXData[RIGHT_STICK_Y_PACKET_LSB] = LOBYTE(Rytemp);
            TXData[RIGHT_STICK_Y_PACKET_MSB] = HIBYTE(Rytemp);

        }
        if(buttonSemaphore)
        {
            buttonSemaphore=0;
            TXData[BUTTON_PACKET_2]=packet2;
            TXData[BUTTON_PACKET_1]=packet1;

        }
        //Clear DPAD
        TXData[BUTTON_PACKET_1] &= DPAD_MASK_OFF;

        USBHD_Endp_DataUp( DEF_UEP1, TXData,20, DEF_UEP_CPY_LOAD );


    }
    MultiTimerStart(timer, 5, JoystickTimer3Callback, userData);
}

void WS2812BTimer4Callback(MultiTimer* timer, void *userData) {
    printf("WS2812B\r\n");
    ws281x_rainbow();
    MultiTimerStart(timer, 100, WS2812BTimer4Callback, userData);
}
void PollSystemInit(void) {
    MultiTimerInstall(PlatformTicksGetFunc);
    MultiTimerStart(&timer1, 5, ButtonTimer1Callback, NULL);
    MultiTimerStart(&timer2, 5, ADCTimer2Callback, NULL);
    MultiTimerStart(&timer3, 5, JoystickTimer3Callback,NULL);
    MultiTimerStart(&timer4, 100, WS2812BTimer4Callback,NULL);
}

/*********************************************************************
 * @fn      SysTick_Handler
 *
 * @brief   SysTick_Handler
 *
 * @return  none
 */
void SysTick_Handler(void) {
    SysTick->CNTL0 = 0;
    SysTick->CNTL1 = 0;
    SysTick->CNTL2 = 0;
    SysTick->CNTL3 = 0;

    SysTick->CNTH0 = 0;
    SysTick->CNTH1 = 0;
    SysTick->CNTH2 = 0;
    SysTick->CNTH3 = 0;
    uwTick++;
}
