/********************************** (C) COPYRIGHT *******************************
 * File Name          : composite_km_desc.h
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2022/08/18
 * Description        : All descriptors for the keyboard and mouse composite device.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/


/*******************************************************************************/
/* Header File */
#include "usbd_desc.h"

/*******************************************************************************/
/* Device Descriptor */
const uint8_t MyDevDescr[ ] =
{
    0x12,                                                   // bLength
    0x01,                                                   // bDescriptorType
    0x00, 0x02,                                             // bcdUSB
    0x00,                                                   // bDeviceClass
    0x00,                                                   // bDeviceSubClass
    0x00,                                                   // bDeviceProtocol
    DEF_USBD_UEP0_SIZE,                                     // bMaxPacketSize0
    (uint8_t)DEF_USB_VID, (uint8_t)( DEF_USB_VID >> 8 ),    // idVendor
    (uint8_t)DEF_USB_PID, (uint8_t)( DEF_USB_PID >> 8 ),    // idProduct
    0x00, DEF_IC_PRG_VER,                                   // bcdDevice
    0x01,                                                   // iManufacturer
    0x02,                                                   // iProduct
    0x03,                                                   // iSerialNumber
    0x01,                                                   // bNumConfigurations
};

/* Configuration Descriptor Set */
const uint8_t MyCfgDescr[ ] =
{
        /************** Configuration Descriptor 1 Bus Powered, 500 mA ****************/
        0x09, /* bLength: Configuration Descriptor size */
        USB_DESC_TYPE_CONFIGURATION, /* bDescriptorType: Configuration */
        USB_CUSTOM_HID_CONFIG_DESC_SIZ,
        /* wTotalLength: Bytes returned */
        0x00,
        0x04,         /*bNumInterfaces: 1 interface*/
        0x01,         /*bConfigurationValue: Configuration value*/
        0x00,         /*iConfiguration: Index of string descriptor describing
      the configuration*/
        0xA0,         /*bmAttributes: Bus Powered, Remote Wakeup*/
        0xFA,         /*MaxPower 500 mA: this current is used for detecting Vbus*/

        /**************Interface Descriptor 0/0 Vendor-Specific, 2 Endpoints****************/
        /* 09 */
        0x09,         /*bLength: Interface Descriptor size*/
        USB_DESC_TYPE_INTERFACE,/*bDescriptorType: Interface descriptor type*/
        0x00,         /*bInterfaceNumber: Number of Interface*/
        0x00,         /*bAlternateSetting: Alternate setting*/
        0x02,         /*bNumEndpoints*/
        0xFF,         /*Vendor-Specific*/
        0x5D,         /*bInterfaceSubClass : 1=BOOT, 0=no boot*/
        0x01,         /*nInterfaceProtocol : 0=none, 1=keyboard, 2=mouse*/
        0x00,            /*iInterface: Index of string descriptor*/
        /**************Unrecognized Class-Specific Descriptor***********************/
        /* 18 */
        0x11,         /*bLength: CUSTOM_HID Descriptor size*/
        0x21, /*bDescriptorType: CUSTOM_HID*/
        0x10,0x01,0x01,0x25,0x81,0x14,0x03,0x03,
        0x03,0x04,0x13,0x02,0x08,0x03,0x03,
        /**************Endpoint Descriptor 81 1 In, Interrupt, 4 ms******************/
        /* 27 */
        0x07,          /*bLength: Endpoint Descriptor size*/
        USB_DESC_TYPE_ENDPOINT, /*bDescriptorType:*/

        CUSTOM_HID_EPIN_ADDR,     /*bEndpointAddress: Endpoint Address (IN)*/
        0x03,          /*bmAttributes: Interrupt endpoint*/
        CUSTOM_HID_EPIN_SIZE, /*wMaxPacketSize: 2 Byte max */
        0x00,
        CUSTOM_HID_FS_BINTERVAL,          /*bInterval: Polling Interval */
        /**************Endpoint Descriptor 02 2 Out, Interrupt, 8 ms******************/
        /* 34 */
        0x07,          /*bLength: Endpoint Descriptor size*/
        USB_DESC_TYPE_ENDPOINT, /*bDescriptorType:*/

        0x02,     /*bEndpointAddress: Endpoint Address (IN)*/
        0x03,          /*bmAttributes: Interrupt endpoint*/
        0x20, /*wMaxPacketSize: 2 Byte max */
        0x00,
        0x08,          /*bInterval: Polling Interval */

        /**************Interface Descriptor 1/0 Vendor-Specific, 2 Endpoints****************/
        /* 09 */
        0x09,         /*bLength: Interface Descriptor size*/
        USB_DESC_TYPE_INTERFACE,/*bDescriptorType: Interface descriptor type*/
        0x01,         /*bInterfaceNumber: Number of Interface*/
        0x00,         /*bAlternateSetting: Alternate setting*/
        0x02,         /*bNumEndpoints*/
        0xFF,         /*Vendor-Specific*/
        0x5D,         /*bInterfaceSubClass : 1=BOOT, 0=no boot*/
        0x01,         /*nInterfaceProtocol : 0=none, 1=keyboard, 2=mouse*/
        0x00,            /*iInterface: Index of string descriptor*/
        /**************Unrecognized Class-Specific Descriptor***********************/
        /* 18 */
        0x1B,         /*bLength: CUSTOM_HID Descriptor size*/
        0x21, /*bDescriptorType: CUSTOM_HID*/
        0x00,0x01,0x01,0x01,0x83,0x40,0x01,0x04,
        0x20,0x16,0x85,0x00,0x00,0x00,0x00,0x00,
        0x00,0x16,0x05,0x00,0x00,0x00,0x00,0x00,
        0x00,
        /**************Endpoint Descriptor 81 1 In, Interrupt, 4 ms******************/
        /* 27 */
        0x07,          /*bLength: Endpoint Descriptor size*/
        USB_DESC_TYPE_ENDPOINT, /*bDescriptorType:*/

        0x83,     /*bEndpointAddress: Endpoint Address (IN)*/
        0x03,          /*bmAttributes: Interrupt endpoint*/
        0x20, /*wMaxPacketSize: 2 Byte max */
        0x00,
        0x02,          /*bInterval: Polling Interval */
        /**************Endpoint Descriptor 02 2 Out, Interrupt, 8 ms******************/
        /* 34 */
        0x07,          /*bLength: Endpoint Descriptor size*/
        USB_DESC_TYPE_ENDPOINT, /*bDescriptorType:*/

        0x04,     /*bEndpointAddress: Endpoint Address (IN)*/
        0x03,          /*bmAttributes: Interrupt endpoint*/
        0x20, /*wMaxPacketSize: 2 Byte max */
        0x00,
        0x04,          /*bInterval: Polling Interval */

        /**************Interface Descriptor 2/0 Vendor-Specific, 2 Endpoints****************/
        /* 09 */
        0x09,         /*bLength: Interface Descriptor size*/
        USB_DESC_TYPE_INTERFACE,/*bDescriptorType: Interface descriptor type*/
        0x02,         /*bInterfaceNumber: Number of Interface*/
        0x00,         /*bAlternateSetting: Alternate setting*/
        0x01,         /*bNumEndpoints*/
        0xFF,         /*Vendor-Specific*/
        0x5D,         /*bInterfaceSubClass : 1=BOOT, 0=no boot*/
        0x02,         /*nInterfaceProtocol : 0=none, 1=keyboard, 2=mouse*/
        0x00,            /*iInterface: Index of string descriptor*/
        /**************Unrecognized Class-Specific Descriptor***********************/
        /* 18 */
        0x09,         /*bLength: CUSTOM_HID Descriptor size*/
        0x21, /*bDescriptorType: CUSTOM_HID*/
        0x00,0x01,0x01,0x22,0x86,0x07,0x00,
        /**************Endpoint Descriptor 81 1 In, Interrupt, 4 ms******************/
        /* 27 */
        0x07,          /*bLength: Endpoint Descriptor size*/
        USB_DESC_TYPE_ENDPOINT, /*bDescriptorType:*/

        0x86,     /*bEndpointAddress: Endpoint Address (IN)*/
        0x03,          /*bmAttributes: Interrupt endpoint*/
        0x20, /*wMaxPacketSize: 2 Byte max */
        0x00,
        0x10,          /*bInterval: Polling Interval */

        /**************nterface Descriptor 3/0 Vendor-Specific, 0 Endpoints****************/
        /* 09 */
        0x09,         /*bLength: Interface Descriptor size*/
        USB_DESC_TYPE_INTERFACE,/*bDescriptorType: Interface descriptor type*/
        0x03,         /*bInterfaceNumber: Number of Interface*/
        0x00,         /*bAlternateSetting: Alternate setting*/
        0x00,         /*bNumEndpoints*/
        0xFF,         /*Vendor-Specific*/
        0xFD,         /*bInterfaceSubClass : 1=BOOT, 0=no boot*/
        0x13,         /*nInterfaceProtocol : 0=none, 1=keyboard, 2=mouse*/
        0x04,            /*iInterface: Index of string descriptor*/
        /**************Unrecognized Class-Specific Descriptor***********************/
        /* 18 */
        0x06,         /*bLength: CUSTOM_HID Descriptor size*/
        0x41, /*bDescriptorType: CUSTOM_HID*/
        0x00,0x01,0x01,0x03
};

/* Keyboard Report Descriptor */
const uint8_t JoystickRepDesc[ ] =
{
        0x05, 0x01,       // USAGE_PAGE (Generic Desktop)
        0x09, 0x02,       // USAGE (Mouse)
        0xa1, 0x01,       // COLLECTION (Application)
        0x09, 0x01,       //   USAGE (Pointer)
        0xa1, 0x00,       //   COLLECTION (Physical)
        0x05, 0x09,       //     USAGE_PAGE (Button)
        0x19, 0x01,       //     USAGE_MINIMUM (Button 1)
        0x29, 0x03,       //     USAGE_MAXIMUM (Button 3)
        0x95, 0x03,       //     REPORT_COUNT (3)
        0x75, 0x01,       //     REPORT_SIZE (1)
        0x15, 0x00,       //     LOGICAL_MINIMUM (0)
        0x25, 0x01,       //     LOGICAL_MAXIMUM (1)
        0x81, 0x02,       //     INPUT (Data,Var,Abs)
        0x95, 0x01,       //     REPORT_COUNT (1)
        0x75, 0x05,       //     REPORT_SIZE (5)
        0x81, 0x01,       //     INPUT (Cnst,Ary,Abs)

        0x05, 0x01,       //     USAGE_PAGE (Generic Desktop)
        0x09, 0x38,       //     USAGE (Wheel)
        0x15, 0x81,       //     LOGICAL_MINIMUM (-127)
        0x25, 0x7f,       //     LOGICAL_MAXIMUM (127)
        0x95, 0x01,       //     REPORT_COUNT (1)
        0x75, 0x08,       //     REPORT_SIZE (8)
        0x81, 0x06,       //     INPUT (Cnst,Ary,Abs)
        0x16, 0x00,0x00,    //     LOGICAL_MINIMUM (0)
        0x26, 0x00,0x01,  //     LOGICAL_MAXIMUM (256)
        0x36, 0x00,0x00,    //     PHYSICAL_MINIMUM (0)
        0x46, 0x00,0x01,    //     PHYSICAL_MAXIMUM (256)
        0x66, 0x00,0x00, //     UNIT (None)
        0x09, 0x30,       //     USAGE (X)
        0x09, 0x31,       //     USAGE (Y)
        0x75, 0x10,       //     REPORT_SIZE (16)
        0x95, 0x02,       //     REPORT_COUNT (2)
        0x81, 0x62,       //     INPUT (Data,Var,Abs,NPrf,Null)
        0xc0,             //     END_COLLECTION
        0xc0              // END_COLLECTION                                            // End Collection
};


/* Language Descriptor */
const uint8_t MyLangDescr[ ] =
{
    0x04,
    0x03,
    0x09,
    0x04
};

/* Manufacturer Descriptor */
const uint8_t MyManuInfo[ ] =
{
        0x16,0x03,0x4C,0x00,0x44,0x00,0x53,0x00,0x43,0x00,0x49,0x00,0x54,0x00,0x45,0x00,
        0x43,0x00,0x48,0x00,0x45,0x00
};

/* Product Information */
const uint8_t MyProdInfo[ ]  =
{
        0x16,0x03,0x4C,0x00,0x44,0x00,0x4A,0x00,0x6F,0x00,0x79,0x00,0x73,0x00,0x74,0x00,
        0x69,0x00,0x63,0x00,0x6B,0x00
};

/* Serial Number Information */
u8 USBD_StringSerial[USB_SIZ_STRING_SERIAL] = {
        USB_SIZ_STRING_SERIAL,
        USB_DESC_TYPE_STRING,};

/**
  * @brief  Convert Hex 32Bits value into char
  * @param  value: value to convert
  * @param  pbuf: pointer to the buffer
  * @param  len: buffer length
  * @retval None
  */
void IntToUnicode(uint32_t value, uint8_t * pbuf, uint8_t len)
{
  uint8_t idx = 0;

  for (idx = 0; idx < len; idx++)
  {
    if (((value >> 28)) < 0xA)
    {
      pbuf[2 * idx] = (value >> 28) + '0';
    }
    else
    {
      pbuf[2 * idx] = (value >> 28) + 'A' - 10;
    }

    value = value << 4;

    pbuf[2 * idx + 1] = 0;
  }
}
void Get_SerialNum(void)
{
  uint32_t deviceserial0, deviceserial1, deviceserial2;

  deviceserial0 = *(uint32_t *) DEVICE_ID1;
  deviceserial1 = *(uint32_t *) DEVICE_ID2;
  deviceserial2 = *(uint32_t *) DEVICE_ID3;

  deviceserial0 += deviceserial2;

  if (deviceserial0 != 0)
  {
    IntToUnicode(deviceserial0, &USBD_StringSerial[2], 8);
    IntToUnicode(deviceserial1, &USBD_StringSerial[18], 4);
  }
}


