/**
  ******************************************************************************
  * @file           : Button.c
  * @brief          : Button Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 LDSCITECHE Inc.
  * 未经作者许可，不得用于其它任何用途
  * 创建日期:2023/10/7
  * 版本：V1.0
  * 版权所有，盗版必究。
  * Copyright(C) 广州联盾电子科技有限公司 LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */
#include "Button.h"
/*********************************************************************
 * @fn      buttonGPIOInit
 *
 * @brief   按键IO初始化
 *
 * @param   none
 *
 * @return  none
 */
void buttonGPIOInit(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); // 使能GPIOA时钟

    // 配置GPIOA的Pin 0为输入下拉模式（IPD）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置GPIOA的Pin 15为输入上拉模式（IPU）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); // 使能GPIOB时钟

    // 配置GPIOB的Pin 3, 4, 5, 6, 7, 8, 9为输入上拉模式（IPU）
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6
                                | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
}


void Button_Handle(u8* Buf)
{

    uint8_t i=2;
    if(SW1()==Bit_SET)//SHIFT
    {
        Buf[0]|=0x02;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }else{
        Buf[0]&=~0x02;
    }
    if(UPKEY()==Bit_RESET)
    {
        Buf[i]=CODE1;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }
    if(LFKEY()==Bit_RESET)
    {
        Buf[i]=CODE2;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }

    if(RGKEY()==Bit_RESET)
    {
        Buf[i]=CODE3;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }

    if(DNKEY()==Bit_RESET)
    {
        Buf[i]=CODE4;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }
    if((TBKEY())==Bit_RESET)//2@
    {

        Buf[i]=CODE5;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }
    if((BKKEY())==Bit_RESET)//左CTRL
    {

        Buf[i]=CODE6;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }
    if((MDKEY())==Bit_RESET)//左ALT
    {

        Buf[i]=CODE7;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }

    if((STKEY())==Bit_RESET)//I
    {

        Buf[i]=CODE8;
        if(++i==8)//切换到下个位置。
        {
            i=2;
        }
    }


}

