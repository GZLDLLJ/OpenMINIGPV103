/**
 ******************************************************************************
 * @file           : ws281x.c
 * @brief          : led Driver
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2021/11/30
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include "PollSystem.h"
#include "Button.h"
#include "adc.h"
#include "ws281x.h"
#include "ch32v10x_usbfs_device.h"
vu32 uwTick;

MultiTimer timer1;
MultiTimer timer2;
MultiTimer timer3;
MultiTimer timer4;

#define  X_BASE             128
#define  Y_BASE             128
#define  DIV                5






void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

uint64_t PlatformTicksGetFunc(void) {
    return uwTick;
}



void keyBoardTimer3Callback(MultiTimer* timer, void *userData) {

    u8 keyBoardReport[8] = { 0 };
    static u8 lastKeyboardReport[8] ={0};
    printf("Keyboard Report\r\n");

    if( USBHD_DevEnumStatus )
    {
        Button_Handle(keyBoardReport);

        if(memcmp(keyBoardReport,lastKeyboardReport,sizeof(keyBoardReport) / sizeof(keyBoardReport[0]))!=0)
        {
            USBHD_Endp_DataUp( DEF_UEP1, keyBoardReport,sizeof(keyBoardReport) / sizeof(keyBoardReport[0]), DEF_UEP_CPY_LOAD );
        }

        memcpy(lastKeyboardReport,keyBoardReport,8);
    }
    MultiTimerStart(timer, 5, keyBoardTimer3Callback, userData);
}

void WS2812BTimer4Callback(MultiTimer* timer, void *userData) {
    printf("WS2812B\r\n");
    ws281x_rainbow();
    MultiTimerStart(timer, 100, WS2812BTimer4Callback, userData);
}
void PollSystemInit(void) {
    MultiTimerInstall(PlatformTicksGetFunc);
    MultiTimerStart(&timer3, 5, keyBoardTimer3Callback,NULL);
    MultiTimerStart(&timer4, 100, WS2812BTimer4Callback,NULL);
}

/*********************************************************************
 * @fn      SysTick_Handler
 *
 * @brief   SysTick_Handler
 *
 * @return  none
 */
void SysTick_Handler(void) {
    SysTick->CNTL0 = 0;
    SysTick->CNTL1 = 0;
    SysTick->CNTL2 = 0;
    SysTick->CNTL3 = 0;

    SysTick->CNTH0 = 0;
    SysTick->CNTH1 = 0;
    SysTick->CNTH2 = 0;
    SysTick->CNTH3 = 0;
    uwTick++;
}
