/**
  ******************************************************************************
  * @file           : Button.h
  * @brief          : Button Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2023/10/7
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */

#ifndef USERBSP_BUTTON_H_
#define USERBSP_BUTTON_H_

#include "debug.h"

#define  UPKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)//PB9
#define  DNKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)//PB8
#define  LFKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)//PB7
#define  RGKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)//PB6
#define  BKKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)//PB5
#define  MDKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)//PB4
#define  STKEY()             GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)//PB3
#define  TBKEY()             GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)//PA15
#define  SW1()               GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)//PA0

#define BIT0                    ((uint32_t)0x01)
#define BIT1                    ((uint32_t)0x02)
#define BIT2                    ((uint32_t)0x04)
#define BIT3                    ((uint32_t)0x08)
#define BIT4                    ((uint32_t)0x10)
#define BIT5                    ((uint32_t)0x20)
#define BIT6                    ((uint32_t)0x40)
#define BIT7                    ((uint32_t)0x80)

#define  CODE1            0x1E
#define  CODE2            0x1F
#define  CODE3            0x20
#define  CODE4            0x21
#define  CODE5            0x22
#define  CODE6            0x23
#define  CODE7            0x24
#define  CODE8            0x25


extern void buttonGPIOInit(void);
extern u8 Button_scan(void);
extern void Button_Handle(u8* bt,u8* whl);
extern void KB_Handle(u8* Buf);
#endif /* USERBSP_BUTTON_H_ */
