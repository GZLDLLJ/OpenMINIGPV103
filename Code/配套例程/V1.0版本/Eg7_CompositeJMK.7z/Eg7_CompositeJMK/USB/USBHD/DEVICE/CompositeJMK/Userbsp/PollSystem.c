/**
 ******************************************************************************
 * @file           : ws281x.c
 * @brief          : led Driver
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2021/11/30
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include "PollSystem.h"
#include "Button.h"
#include "adc.h"
#include "ws281x.h"
#include "ch32v10x_usbfs_device.h"
vu32 uwTick;

MultiTimer timer1;
MultiTimer timer2;
MultiTimer timer3;
MultiTimer timer4;
MultiTimer timer5;

#define  X_BASE             128
#define  Y_BASE             128
#define  DIV                5


DEVICE_TypeDef myHid=DEVICE_JOYSTICK;



void SysTick_Handler(void) __attribute__((interrupt("WCH-Interrupt-fast")));

uint64_t PlatformTicksGetFunc(void) {
    return uwTick;
}

/**
  * @brief This function provides minimum delay (in milliseconds) based
  *        on variable incremented.
  * @note In the default implementation , SysTick timer is the source of time base.
  *       It is used to generate interrupts at regular time intervals where uwTick
  *       is incremented.
  * @note This function is declared as __weak to be overwritten in case of other
  *       implementations in user file.
  * @param Delay specifies the delay time length, in milliseconds.
  * @retval None
  */
#define HAL_MAX_DELAY      0xFFFFFFFFU
void HAL_Delay(uint32_t Delay)
{
  uint32_t tickstart = PlatformTicksGetFunc();
  uint32_t wait = Delay;

  /* Add a freq to guarantee minimum wait */
  if (wait < HAL_MAX_DELAY)
  {
    wait += (uint32_t)(1);
  }

  while ((PlatformTicksGetFunc() - tickstart) < wait)
  {
  }
}


u8 buttonSemaphore = 0;
u8 button = 0,wheel=0;
void ButtonTimer1Callback(MultiTimer* timer, void *userData) {
    printf("Button_scan\r\n");
    if (buttonSemaphore == 0) {
        if(myHid==DEVICE_JOYSTICK)
         {
             button=Button_scan();
         }else if(myHid==DEVICE_MOUSE){
             button = 0;
             wheel=0;
             Button_Handle(&button,&wheel);

         }




        buttonSemaphore = 1;
    }

    MultiTimerStart(timer, 5, ButtonTimer1Callback, userData);
}
u8 adcSemaphore = 0;
u8 xtemp = 0, ytemp = 0;
u16 adxsum=0,adysum=0,adcount=0;
void ADCTimer2Callback(MultiTimer* timer, void *userData) {
    printf("ADC Sample\r\n");

    if (adcSemaphore == 0) {

        adysum+=Get_Adc(1);
        adxsum+=Get_Adc(2);
        adcount+=1;
        if(++adcount==10)
        {
            printf("x=%d,y=%d\r\n",adysum/adcount,adxsum/adcount);
            ytemp = map(adysum/adcount, AD_XMIN, AD_XMAX, 0, 255);
            xtemp = map(adxsum/adcount, AD_YMIN, AD_YMAX, 0, 255);
            adysum=0;
            adxsum=0;
            adcount=0;
            adcSemaphore = 1;
        }


    }
    MultiTimerStart(timer, 5, ADCTimer2Callback, userData);
}
u8 Joystick_Report[4] = { 0 };
u8 LastJoystick_Report[4] = { 0 };

void joyStickReportHandler(void)
{
    if(adcSemaphore)
    {
        adcSemaphore=0;
        Joystick_Report[1]=ytemp;
        Joystick_Report[0]=xtemp;
    }
    if(buttonSemaphore)
    {
        buttonSemaphore=0;
        Joystick_Report[2]=button;
    }

    if(memcmp(LastJoystick_Report,Joystick_Report,3)!=0)
    {
        USBHD_Endp_DataUp( DEF_UEP1, Joystick_Report,3, DEF_UEP_CPY_LOAD );
    }

    memcpy(LastJoystick_Report,Joystick_Report,3);
}
void mouseReportHandler(void)
{
    memset(Joystick_Report,0,4);
    if(adcSemaphore)
    {
        adcSemaphore=0;
        if(xtemp>(X_BASE+20))
        {
            Joystick_Report[1]=((xtemp-X_BASE)>>DIV)+1;;
        }
        if(xtemp<(X_BASE-20))
        {
            Joystick_Report[1]=(u8)-(((X_BASE-xtemp)>>DIV)+1);
        }
        if(ytemp>(Y_BASE+20))
        {
            Joystick_Report[2]=((ytemp-Y_BASE)>>DIV)+1;
        }
        if(ytemp<(Y_BASE-20))
        {
            Joystick_Report[2]=(u8)-(((Y_BASE-ytemp)>>DIV)+1);
        }

    }
    if(buttonSemaphore)
    {
        buttonSemaphore=0;

        Joystick_Report[0]=button;
        Joystick_Report[3]=wheel;
    }

    USBHD_Endp_DataUp( DEF_UEP2, Joystick_Report,4, DEF_UEP_CPY_LOAD );

}
void keyBoardReportHandler(void)
{
    u8 keyBoardReport[8] = { 0 };
    static u8 lastKeyboardReport[8] ={0};
    printf("Keyboard Report\r\n");
    KB_Handle(keyBoardReport);

    if(memcmp(keyBoardReport,lastKeyboardReport,sizeof(keyBoardReport) / sizeof(keyBoardReport[0]))!=0)
    {
        USBHD_Endp_DataUp( DEF_UEP3, keyBoardReport,sizeof(keyBoardReport) / sizeof(keyBoardReport[0]), DEF_UEP_CPY_LOAD );
    }

    memcpy(lastKeyboardReport,keyBoardReport,8);
}
void JoystickTimer3Callback(MultiTimer* timer, void *userData) {


    if( USBHD_DevEnumStatus )
    {
        if(myHid==DEVICE_JOYSTICK)
         {
            joyStickReportHandler();
         }else if(myHid==DEVICE_MOUSE){
             mouseReportHandler();

         }else if(myHid==DEVICE_KEYBOARD){
             keyBoardReportHandler();
         }

    }
    MultiTimerStart(timer, 5, JoystickTimer3Callback, userData);
}

void WS2812BTimer4Callback(MultiTimer* timer, void *userData) {

    printf("WS2812B\r\n");

    if(myHid==DEVICE_JOYSTICK)
    {
        WS_WriteAll_RGB(0xFF,0x00,0x00);
    }else if(myHid==DEVICE_MOUSE){
        WS_WriteAll_RGB(0x00,0xFF,0x00);

    }else if(myHid==DEVICE_KEYBOARD){
        WS_WriteAll_RGB(0x00,0x00,0xFF);
    }

    MultiTimerStart(&timer4, 500, WS2812BTimer4Callback,NULL);

}

void DeviceSwitchTimer5Callback(MultiTimer* timer, void *userData) {
    printf("DeviceSwitch\r\n");
    static u16 swtick=0;
    if(UPKEY()==0)
    {
        if(swtick++>300)
        {
            swtick=0;
            if(++myHid>DEVICE_KEYBOARD)
            {
                myHid=DEVICE_JOYSTICK;

            }
            MultiTimerStart(&timer4, 100, WS2812BTimer4Callback,NULL);
        }
    }else{
        swtick=0;
    }
    MultiTimerStart(timer, 10, DeviceSwitchTimer5Callback, userData);
}
void PollSystemInit(void) {
    MultiTimerInstall(PlatformTicksGetFunc);
    MultiTimerStart(&timer1, 5, ButtonTimer1Callback, NULL);
    MultiTimerStart(&timer2, 5, ADCTimer2Callback, NULL);
    MultiTimerStart(&timer3, 5, JoystickTimer3Callback,NULL);
    MultiTimerStart(&timer4, 100, WS2812BTimer4Callback,NULL);
    MultiTimerStart(&timer5, 10, DeviceSwitchTimer5Callback,NULL);
}

/*********************************************************************
 * @fn      SysTick_Handler
 *
 * @brief   SysTick_Handler
 *
 * @return  none
 */
void SysTick_Handler(void) {
    SysTick->CNTL0 = 0;
    SysTick->CNTL1 = 0;
    SysTick->CNTL2 = 0;
    SysTick->CNTL3 = 0;

    SysTick->CNTH0 = 0;
    SysTick->CNTH1 = 0;
    SysTick->CNTH2 = 0;
    SysTick->CNTH3 = 0;
    uwTick++;
}
