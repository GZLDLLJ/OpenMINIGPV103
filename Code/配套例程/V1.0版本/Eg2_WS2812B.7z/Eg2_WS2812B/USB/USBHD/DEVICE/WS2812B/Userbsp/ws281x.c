/**
 ******************************************************************************
 * @file           : ws281x.c
 * @brief          : led Driver
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
 * δ���������ɣ��������������κ���;
 * ��������:2021/11/30
 * �汾��V1.0
 * ��Ȩ���У�����ؾ���
 * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
 * All rights reserved
 *
 ******************************************************************************
 */

#include <string.h>
#include <ws281x.h>

#define      PWM_TICK_BASE    10

u8 BreathType = 0;    //RGB????
u8 R_duty = 0;    //?????
u8 G_duty = 0;    //?????
u8 B_duty = 0;    //?????
u16 Swich_TIME = 0;    //??????

/* CH1CVR register Definition */
#define TIM3_CH1CVR_ADDRESS    0x40000434

/* Private variables */
int16_t send_Buf[NUM];

/*********************************************************************
 * @fn      TIM1_PWMOut_Init
 *
 * @brief   Initializes TIM1 PWM output.
 *
 * @param   arr - the period value.
 *          psc - the prescaler value.
 *          ccp - the pulse value.
 *
 * @return  none
 */
void TIM3_PWMOut_Init(u16 arr, u16 psc, u16 ccp) {
    GPIO_InitTypeDef GPIO_InitStructure = { 0 };
    TIM_OCInitTypeDef TIM_OCInitStructure = { 0 };
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure = { 0 };

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    TIM_TimeBaseInitStructure.TIM_Period = arr;
    TIM_TimeBaseInitStructure.TIM_Prescaler = psc;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = ccp;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM3, &TIM_OCInitStructure);

    TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Disable);
    TIM_ARRPreloadConfig(TIM3, ENABLE);
}

/*********************************************************************
 * @fn      TIM1_DMA_Init
 *
 * @brief   Initializes the TIM DMAy Channelx configuration.
 *
 * @param   DMA_CHx -
 *            x can be 1 to 7.
 *          ppadr - Peripheral base address.
 *          memadr - Memory base address.
 *          bufsize - DMA channel buffer size.
 *
 * @return  none
 */
void TIM3_DMA_Init(DMA_Channel_TypeDef *DMA_CHx, u32 ppadr, u32 memadr,
        u16 bufsize) {
    DMA_InitTypeDef DMA_InitStructure = { 0 };

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA_CHx);
    DMA_InitStructure.DMA_PeripheralBaseAddr = ppadr;
    DMA_InitStructure.DMA_MemoryBaseAddr = memadr;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = bufsize;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_Medium;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA_CHx, &DMA_InitStructure);

    DMA_Cmd(DMA_CHx, ENABLE);
}

/*******************************************************************************
 * Function Name  : WS281xInit
 * Description    : WS281x LED��ʼ��
 * Input          : None
 * Return         : None
 *******************************************************************************/
void WS281xInit(void) {
    Delay_Ms(50);
    TIM3_PWMOut_Init(89, 0, 0);
    TIM3_DMA_Init(DMA1_Channel3, (u32) TIM3_CH1CVR_ADDRESS, (u32) &send_Buf,
            NUM);
    TIM_DMACmd(TIM3, TIM_DMA_Update, ENABLE);
    TIM_Cmd(TIM3, ENABLE);
    TIM_CtrlPWMOutputs(TIM3, ENABLE);

}
void WS281x_SetPixelColor(uint16_t n, uint32_t GRBColor) {
    uint8_t i;
    if (n < PIXEL_NUM) {
        for (i = 0; i < 24; ++i)
            send_Buf[24 * n + i] = (((GRBColor << i) & 0X800000) ? WS1 : WS0);
    }
}
//�����ɫ�@ʾ�����O���ɫ�ጢ�ɫ�������뾏��ֻ�Ј���ԓ�������u���M���@ʾ��
void ws281x_show(void) {

    DMA_SetCurrDataCounter(DMA1_Channel3, NUM);    //DMAͨ����DMA����Ĵ�С
    DMA_Cmd(DMA1_Channel3, ENABLE);  //ʹ��USART1 TX DMA1 ��ָʾ��ͨ��
    TIM_Cmd(TIM3, ENABLE);
    while(DMA_GetFlagStatus(DMA1_FLAG_TC3)==RESET);
    TIM_Cmd(TIM3, DISABLE);
    DMA_Cmd(DMA1_Channel3, DISABLE);  //�P�]USART1 TX DMA1 ��ָʾ��ͨ��
    DMA_ClearFlag(DMA1_FLAG_TC3);
}
uint32_t WS281x_Color(uint8_t red, uint8_t green, uint8_t blue) {
    return green << 16 | red << 8 | blue;
}
// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r
uint32_t Wheel(uint8_t WheelPos) {
    WheelPos = 255 - WheelPos;
    if (WheelPos < 85) {
        return WS281x_Color(255 - WheelPos * 3, 0, WheelPos * 3);
    }
    if (WheelPos < 170) {
        WheelPos -= 85;
        return WS281x_Color(0, WheelPos * 3, 255 - WheelPos * 3);
    }
    WheelPos -= 170;
    return WS281x_Color(WheelPos * 3, 255 - WheelPos * 3, 0);
}
void ws281x_rainbow(void) {
    static uint16_t i, j;

        for (i = 0; i < PIXEL_NUM; i++) {
            WS281x_SetPixelColor(i, Wheel((i + j) & 255));
        }

        ws281x_show();
        if(j++==256)
        {
            j=0;
        }
}

