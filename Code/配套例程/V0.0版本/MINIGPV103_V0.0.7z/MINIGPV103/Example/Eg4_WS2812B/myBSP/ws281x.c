/**
  ******************************************************************************
  * @file           : ws281x.c
  * @brief          : led Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2021/11/30
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved		
  *
  ******************************************************************************
  */

#include "ws281x.h"
#include <string.h>

#define      PWM_TICK_BASE    10

u8 BreathType=0;    //RGB????
u8 R_duty=0;    //?????
u8 G_duty=0;    //?????
u8 B_duty=0;    //?????
u16 Swich_TIME=0;//??????

/* CH1CVR register Definition */
#define TIM3_CH1CVR_ADDRESS    0x40000434

/* Private variables */
int16_t send_Buf[NUM];

/*********************************************************************
 * @fn      TIM1_PWMOut_Init
 *
 * @brief   Initializes TIM1 PWM output.
 *
 * @param   arr - the period value.
 *          psc - the prescaler value.
 *          ccp - the pulse value.
 *
 * @return  none
 */
void TIM3_PWMOut_Init(u16 arr, u16 psc, u16 ccp)
{
    GPIO_InitTypeDef        GPIO_InitStructure = {0};
    TIM_OCInitTypeDef       TIM_OCInitStructure = {0};
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    TIM_TimeBaseInitStructure.TIM_Period = arr;
    TIM_TimeBaseInitStructure.TIM_Prescaler = psc;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = ccp;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM3, &TIM_OCInitStructure);

    TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Disable);
    TIM_ARRPreloadConfig(TIM3, ENABLE);
}

/*********************************************************************
 * @fn      TIM1_DMA_Init
 *
 * @brief   Initializes the TIM DMAy Channelx configuration.
 *
 * @param   DMA_CHx -
 *            x can be 1 to 7.
 *          ppadr - Peripheral base address.
 *          memadr - Memory base address.
 *          bufsize - DMA channel buffer size.
 *
 * @return  none
 */
void TIM3_DMA_Init(DMA_Channel_TypeDef *DMA_CHx, u32 ppadr, u32 memadr, u16 bufsize)
{
    DMA_InitTypeDef DMA_InitStructure = {0};

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA_CHx);
    DMA_InitStructure.DMA_PeripheralBaseAddr = ppadr;
    DMA_InitStructure.DMA_MemoryBaseAddr = memadr;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = bufsize;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA_CHx, &DMA_InitStructure);

    DMA_Cmd(DMA_CHx, ENABLE);
}
/*******************************************************************************
* Function Name  : WS_WriteAll_RGB
* Description    : ��������LEDΪͬһ����ɫ
* Input          : n_R����ɫռ�ȣ�   n_G����ɫռ�� ��  n_B����ɫռ��
* Return         : None
*******************************************************************************/
void WS_WriteAll_RGB(uint8_t n_R, uint8_t n_G, uint8_t n_B)
{
    uint16_t i, j;
    uint8_t dat[24];
    // ��RGB���ݽ���ת��
    for (i = 0; i < 8; i++)
    {
        dat[i] = ((n_G & 0x80) ? WS1 : WS0);
        n_G <<= 1;
    }
    for (i = 0; i < 8; i++)
    {
        dat[i + 8] = ((n_R & 0x80) ? WS1 : WS0);
        n_R <<= 1;
    }
    for (i = 0; i < 8; i++)
    {
        dat[i + 16] = ((n_B & 0x80) ? WS1 : WS0);
        n_B <<= 1;
    }
    for (i = 0; i < PIXEL_NUM; i++)
    {
        for (j = 0; j < 24; j++)
        {
            send_Buf[i * 24 + j] = dat[j];
        }
    }
    for (i = PIXEL_NUM * 24; i < NUM; i++)
        send_Buf[i] = 0;    // ռ�ձȱ�Ϊ0��ȫΪ�͵�ƽ

}
/*******************************************************************************
* Function Name  : WS281xInit
* Description    : WS281x LED��ʼ��
* Input          : None
* Return         : None
*******************************************************************************/
void WS281xInit(void)
{
    Delay_Ms(50);
    WS_WriteAll_RGB(0x7f,0,0);//set red
    TIM3_PWMOut_Init(60, 0, 0);
    TIM3_DMA_Init(DMA1_Channel3, (u32)TIM3_CH1CVR_ADDRESS, (u32)&send_Buf, NUM);

    TIM_DMACmd(TIM3, TIM_DMA_Update, ENABLE);
    TIM_Cmd(TIM3, ENABLE);
    TIM_CtrlPWMOutputs(TIM3, ENABLE);
    Delay_Ms(500);
    WS_WriteAll_RGB(0,0x7f,0);//set green
    Delay_Ms(500);
    WS_WriteAll_RGB(0,0,0x7f);//set blue
    Delay_Ms(500);
    WS_WriteAll_RGB(0,0,0x00);//set black
    Delay_Ms(500);
}

#if(WS_EFFECT == RAINBOW)
    uint32_t WS281x_Color(uint8_t red, uint8_t green, uint8_t blue) { return green << 16 | red << 8 | blue; }
    uint32_t Wheel(uint8_t WheelPos)
    {
        WheelPos = 255 - WheelPos;
        if (WheelPos < 85)
        {
            return WS281x_Color(255 - WheelPos * 3, 0, WheelPos * 3);
        }
        if (WheelPos < 170)
        {
            WheelPos -= 85;
            return WS281x_Color(0, WheelPos * 3, 255 - WheelPos * 3);
        }
        WheelPos -= 170;
        return WS281x_Color(WheelPos * 3, 255 - WheelPos * 3, 0);
    }
    void WS281x_SetPixelColor(uint16_t n, uint32_t GRBColor)
    {
        uint8_t i;
        if (n < PIXEL_NUM)
        {
            for (i = 0; i < 24; ++i)
                send_Buf[24 * n + i] = (((GRBColor << i) & 0X800000) ? WS1 : WS0);
        }
    }
    void rainbow(uint8_t wait)
    {
        uint16_t i, j;
    //    for (i = 0; i < PIXEL_NUM; i++)
    //    {
    //        WS281x_SetPixelColor(i, Wheel((i + j) & 255));
    //    }

        for(j = 0; j < 256 * 5; j++) // 5 cycles of all colors on wheel
        {

            for(i = 0; i < PIXEL_NUM; i++)
            {

                WS281x_SetPixelColor(i, Wheel((i + j) & 255));
            }
            TIM_CtrlPWMOutputs(TIM3, ENABLE);
            Delay_Ms(wait);
        }

        //WS_Load();
    }

#elif(WS_EFFECT == COLORFU_FRADIENT)
    void Colorful_Gradient_Pro(void)
    {
        switch(BreathType)
        {
                case 0://red
                {
                        R_duty=85;
                        G_duty=1;
                        B_duty=1;
                        Swich_TIME=0;
                        BreathType=1;
                }break;
                case 1://red->orange
                {
                        R_duty-=1;
                        G_duty+=2;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=2;
                        }
                }break;
                case 2://orange
                {
                        R_duty=75;
                        G_duty=23;
                        B_duty=0;
                                Swich_TIME=0;
                                BreathType=3;
                }break;
                case 3://orange->yello
                {
                        G_duty+=5;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=4;
                        }
                }break;
                case 4://yello
                {
                        R_duty=74;
                        G_duty=75;
                        B_duty=1;
                                Swich_TIME=0;
                                BreathType=5;
                }break;
                case 5://yello->green
                {
                        R_duty-=7;
                        B_duty+=1;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=6;
                        }
                }break;
                case 6://green
                {
                        R_duty=0;
                        G_duty=75;
                        B_duty=9;
                                Swich_TIME=0;
                                BreathType=7;
                }break;
                case 7://green->cyan
                {
                        B_duty+=6;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=8;
                        }
                }break;
                case 8://cyan
                {
                        R_duty=0;
                        G_duty=75;
                        B_duty=72;
                                Swich_TIME=0;
                                BreathType=9;
                }break;
                case 9://cyan->blue
                {
                        G_duty-=7;
                        B_duty+=1;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=10;
                        }
                }break;
                case 10://blue
                {
                        R_duty=4;
                        G_duty=1;
                        B_duty=82;
                                Swich_TIME=0;
                                BreathType=11;
                }break;
                case 11://blue->purple
                {
                        R_duty+=7;
                        B_duty-=1;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=12;
                        }
                }break;
                case 12://purple
                {
                        R_duty=75;
                        G_duty=1;
                        B_duty=67;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=13;
                        }
                }break;
                case 13://purple->red
                {
                        R_duty+=1;
                        B_duty-=6;
                        if(++Swich_TIME>=PWM_TICK_BASE)
                        {
                                Swich_TIME=0;
                                BreathType=0;
                        }
                }break;

        }
        WS_WriteAll_RGB(R_duty,G_duty,B_duty);
        Delay_Ms(100);
    }

#endif


