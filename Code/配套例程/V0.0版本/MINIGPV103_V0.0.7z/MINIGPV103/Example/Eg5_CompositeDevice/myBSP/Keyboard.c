/**
  ******************************************************************************
  * @file           : gamepad.c
  * @brief          : Gamepad Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2021/11/30
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved		
  *
  ******************************************************************************
  */

#include "Keyboard.h"
#include <string.h>
#include "adc.h"
#include "myhid.h"
#include "key.h"
#include "myFSM.h"

#define  X_BASE             128
#define  Y_BASE             128
#define  DIV                5


uint8_t Keyboad_Buf[8]={0};
uint8_t lastshift=0,currentshift=0;
uint8_t lastkeycode[8]={0},currentkeycode[8]={0};
static uint8_t KdataFL=0;
//�������ϱ�����
void Keyboard_Handle(void)
{	
    if(myfsm.hiddev!=KeyBoard)
    {
        return;
    }
    memset(Keyboad_Buf,0,8);
    uint8_t i=0;uint8_t idx=2;

    if(SW1==1)
    {
        currentshift|=0x02;
        Keyboad_Buf[0]=currentshift;
    }else{

        currentshift&=(~0x02);
        Keyboad_Buf[0]=currentshift;
    }

    if(UPKEY==0)
    {
        currentkeycode[0]=CODE1;
    }else{
        currentkeycode[0]=0x00;
    }
    if(DNKEY==0)
    {
        currentkeycode[1]=CODE2;
    }else{
        currentkeycode[1]=0x00;
    }
    if(LFKEY==0)
    {
        currentkeycode[2]=CODE3;
    }else{
        currentkeycode[2]=0x00;
    }
    if(RGKEY==0)
    {
        currentkeycode[3]=CODE4;
    }else{
        currentkeycode[3]=0x00;
    }
    if(BKKEY==0)
    {
        currentkeycode[4]=CODE5;
    }else{
        currentkeycode[4]=0x00;
    }
    if(MDKEY==0)
    {
        currentkeycode[5]=CODE6;
    }else{
        currentkeycode[5]=0x00;
    }
    if(STKEY==0)
    {
        currentkeycode[6]=CODE7;
    }else{
        currentkeycode[6]=0x00;
    }
    if(TBKEY==0)
    {
        currentkeycode[7]=CODE8;
    }else{
        currentkeycode[7]=0x00;
    }

    for(i=0;i<8;i++)
    {
        if(currentkeycode[i]!=lastkeycode[i])
        {
            Keyboad_Buf[idx]=currentkeycode[i];
            if(++idx>=8)
            {
                idx=2;
            }
            KdataFL=1;
        }else{
            Keyboad_Buf[idx]=0x00;
        }
    }
    if(currentshift!=lastshift)
    {
        KdataFL=1;
    }

    if(KdataFL!=0)
    {
        KdataFL=0;
        if(Ready)
        {
            while( Endp1Busy )
            {
                ;                                               //���æ����һ������û�д���ȥ������ȴ���
            }
            Endp1Busy = 1;                                      //����Ϊæ״̬
            memcpy(pEP1_IN_DataBuf, Keyboad_Buf, 8);
            DevEP1_IN_Deal(8);
        }


    }
    memcpy(lastkeycode,currentkeycode,8);
    lastshift=currentshift;
}	








