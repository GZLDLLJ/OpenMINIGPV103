/**
  ******************************************************************************
  * @file           : myhid.c
  * @brief          : myhid
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2021/11/30
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved
  *
  ******************************************************************************
  */
#ifndef __MYHID_H
#define __MYHID_H

#include "ch32v10x_conf.h"

#define         UID_BASE              0x1FFFF7E8UL    /*!< Unique device ID register base address */
#define         DEVICE_ID1          (UID_BASE)
#define         DEVICE_ID2          (UID_BASE + 0x4)
#define         DEVICE_ID3          (UID_BASE + 0x8)

#define LOBYTE(x)  ((uint8_t)((x) & 0x00FFU))
#define HIBYTE(x)  ((uint8_t)(((x) & 0xFF00U) >> 8U))

//Serial String
#define  USB_SIZ_STRING_SERIAL       0x1A
#define  USB_DESC_TYPE_STRING        0x03U

#define USBD_VID        0x810
#define USBD_PID_FS     0x5


extern volatile UINT8   Ready;
extern volatile UINT8   Endp1Busy;
extern volatile UINT8   Endp2Busy;
extern volatile UINT8   Endp3Busy;
#endif
