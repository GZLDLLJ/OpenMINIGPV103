/**
  ******************************************************************************
  * @file           : key.h
  * @brief          : key Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2022/1/26
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved		
  *
  ******************************************************************************
  */


#ifndef _KEY_H
#define _KEY_H


#include "ch32v10x.h"
#include "ch32v10x_gpio.h"


#define  UPKEY             (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))//PB9
#define  DNKEY             (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8))//PB8
#define  LFKEY             (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7))//PB7
#define  RGKEY             (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6))//PB6

#define  BKKEY             (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5))//PB5
#define  MDKEY             (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4))//PB4
#define  STKEY             (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3))//PB3
#define  TBKEY             (GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15))//PA15

#define   SW1              (GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0))//PA0
extern void KEY_INIT(void);
extern u8 Key_Scan(void);
extern void Key_Handle(uint8_t* kv);

#endif



