/**
  ******************************************************************************
  * @file           : key.c
  * @brief          : key Driver
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 LDSCITECHE Inc.
  * δ���������ɣ��������������κ���;
  * ��������:2021/11/30
  * �汾��V1.0
  * ��Ȩ���У�����ؾ���
  * Copyright(C) �������ܵ��ӿƼ����޹�˾ LDSCITECHE Inc.
  * All rights reserved		
  *
  ******************************************************************************
  */

#include "key.h"

static uint16_t c_tick=0;
/*******************************************************************************
* Function Name  : KEY_INIT
* Description    : Initializes GPIOB
* Input          : None
* Return         : None
*******************************************************************************/
void KEY_INIT(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6
                                  |GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

}


u8 Key_Scan(void)
{
    u8 kv=0;
    kv=(u8)(GPIO_ReadInputData(GPIOB)>>2);
    kv=~kv;
    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)==Bit_RESET)
    {
        kv|=0x01;
    }else{
        kv&=0xFE;

    }
    return kv;
}


void Key_Handle(uint8_t* kv)
{

    if((LFKEY)==Bit_RESET)
    {
        kv[0]|=0x01;
    }

    if((RGKEY)==Bit_RESET)
    {
        kv[0]|=0x02;
    }
    if(SW1!=Bit_RESET)
    {
        kv[0]|=0x04;
    }
    if((UPKEY)==Bit_RESET)
    {
        if(c_tick++>5)
        {
            kv[3]=1;
            c_tick=0;
        }
    }
    if((DNKEY)==Bit_RESET)
    {
        if(c_tick++>5)
        {
            kv[3]=(u8)-1;
            c_tick=0;
        }
    }

}







